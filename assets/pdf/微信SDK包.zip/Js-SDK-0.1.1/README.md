gizwits-ws-sdk
=======
v0.1.1

## Description
* A javascript SDK for Gizwits websocket.

## Change log v0.1.1 (2016/05)
* Set SocketType default value to 'ssl_socket'
* Remove SocketType from demo html